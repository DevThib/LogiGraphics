package sample;

import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;

public class ItemsMen {

    MenuBar bar = new MenuBar();

    public ItemsMen(){

        Menu files = new Menu("Solides");

        MenuItem create = new MenuItem("⬜ Rectangle");
        MenuItem open = new MenuItem("📁 Ouvrir");
        MenuItem save = new MenuItem("✅ Enregistrer");

        files.getItems().addAll(create,open,save);

        bar.getMenus().add(files);








    }

    public MenuBar getBar() {
        return bar;
    }
}

