package sample;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.Random;

public class Main extends Application {

    Group group = new Group();
    Scene scene = new Scene(group,1300,900, Color.GREY);

    FlowPane menu = new FlowPane();

    boolean isOnAction = false;
    Node nodeAction = null;

    double moveX = 0;
    double moveY = 0;

    Node selected;

    int selector = 1;

    Circle circle;
    Rectangle rectangle;
    Line line;

    Line indicator = new Line();

   FlowPane underMenu = new FlowPane();

    /* selector :

    1 = rectangle
    2 = cercle
    3 = ligne
    4 = libre

     */

    @Override
    public void start(Stage primaryStage){

        Stage stage = new Stage();
        VBox box = new VBox();
        Label label = new Label();
        label.setText(randomTip());
        label.setFont(new Font("Trebuchet MS",15));
        box.getChildren().addAll(label);
        box.setAlignment(Pos.CENTER);
        stage.setScene(new Scene(box,500,225));
        stage.setTitle("Astuce du jour !");

        /*
        A DEV :

        -système pour enregistrer le projet sous forme de fichiers txt (donc mettre un bouton save)
        -menu en dessous,on change de sélection avec u et on peut cliquer dessus en faisant entrée (sans besoin de cliquer dessus)
        -auto save
        -le menu a gauche apparait quand on sélectionne un truc,il permet de changer la couleur des éléments et leur taille
        -mettre github
        -bouton paramètres
        -gomme grace au substract (créer un rectangle qui efface)
        -outils fusion,qui combine les éléments (shape de ROMAINPC la vidép) (risque d'être assez dur)

         */

        menu.setPadding(new Insets(3));

        Button rectanglee = new Button();
        rectanglee.setMinWidth(50);
        rectanglee.setMinHeight(50);
        rectanglee.setText("■");
        rectanglee.setTextFill(Color.RED);
        rectanglee.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                selector = 1;
                menuSelector();
            }
        });


          Button circlee = new Button();
          circlee.setMinHeight(50);
          circlee.setMinWidth(50);
          circlee.setText("•");
          circlee.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                selector = 2;
                menuSelector();
            }
        });

       Button linee = new Button();
        linee.setMinHeight(50);
        linee.setMinWidth(50);
        linee.setText("/");
        linee.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                selector = 3;
                menuSelector();
            }
        });

        Button back = new Button();
        back.setMinWidth(50);
        back.setMinHeight(50);
        back.setText("back");
        back.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                back();
            }
        });

        Button button = new Button();
        button.setMinWidth(50);
        button.setMinHeight(50);
        button.setPadding(new Insets(2));
        button.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                selector = 4;
                menuSelector();
            }
        });


       menu.getChildren().addAll(rectanglee,circlee,linee,back,button);

       Button save = new Button();
       save.setMinWidth(50);
       save.setText("Save");
       save.setMinHeight(50);









        underMenu.getChildren().addAll(save);

        scene.setOnMouseClicked(new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {

                if(!isOnAction){
                    if(selector != 4){
                        isOnAction = true;
                    }

                    if(selector == 1){

                        rectangle = new Rectangle();

                        rectangle.setOpacity(0.3);
                        rectangle.setY(event.getY());
                        rectangle.setX(event.getX());
                        rectangle.setWidth(6);
                        rectangle.setHeight(6);
                        nodeAction = rectangle;
                        rectangle.setOnMouseClicked(new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent event) {
                                if(selector == 4) {
                                    selected = rectangle;
                                    select();
                                }
                            }
                        });

                        group.getChildren().add(rectangle);
                    }

                    if(selector == 2){
                        circle = new Circle();

                        circle.setOpacity(0.3);
                        circle.setCenterX(event.getX());
                        circle.setCenterY(event.getY());
                        circle.setRadius(15);
                        nodeAction = circle;
                        circle.setOnMouseClicked(new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent event) {
                                if(selector == 4) {

                                    selected = circle;
                                    select();
                                }
                            }
                        });
                        group.getChildren().add(circle);
                    }

                    if(selector == 3){
                        line = new Line();

                        line.setOpacity(0.3);
                        line.setStartX(event.getX());
                        line.setStartY(event.getY());
                        line.setEndY(event.getX());
                        line.setEndY(event.getY());
                        nodeAction = line;
                        line.setOnMouseClicked(new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent event) {
                                if(selector == 4) {

                                    selected = line;
                                    select();
                                }
                            }
                        });
                        group.getChildren().add(line);
                    }


                }else{

                    if(nodeAction.getTypeSelector().equalsIgnoreCase("Circle")){
                        Circle c = (Circle) nodeAction;
                        c.setOpacity(1);
                        nodeAction = c;
                    }
                    if(nodeAction.getTypeSelector().equalsIgnoreCase("Rectangle")){
                        Rectangle c = (Rectangle) nodeAction;
                        c.setOpacity(1);
                        nodeAction = c;
                    }
                    if(nodeAction.getTypeSelector().equalsIgnoreCase("Line")){
                        Line c = (Line) nodeAction;
                        c.setOpacity(1);
                        nodeAction = c;
                    }

                   isOnAction = false;
                   nodeAction = null;
                   moveY = 0;
                   moveX = 0;
                }

            }
        });

        scene.setOnMouseMoved(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                if(isOnAction){

                    if(selector == 1){

                        Rectangle circle1 = (Rectangle) nodeAction;
                        circle1.setWidth(event.getX()-circle1.getX());
                        circle1.setHeight(event.getY()-circle1.getY());
                        rectangle = circle1;

                    }

                    if(selector == 2){

                        moveY = event.getY();
                        moveX = event.getX();
                        Circle circle1 = (Circle) nodeAction;
                        circle1.setRadius(event.getX()-circle1.getCenterX());
                        circle = circle1;

                    }
                    if(selector == 3){

                        line.setEndX(event.getX());
                        line.setEndY(event.getY());

                    }

                }
                analyse(event.getY(), event.getX());
            }
        });


        scene.setOnKeyTyped(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {

                if(event.getCharacter().equalsIgnoreCase("p")){
                    selector++;
                    if(selector > 4){
                        selector = 1;
                    }
                    menuSelector();
                }

                if(event.getCharacter().equalsIgnoreCase("z")){
                    for(int i = 1; i < group.getChildren().size(); i++){
                        group.getChildren().get(i).setTranslateY(group.getChildren().get(i).getTranslateY()-10);
                    }
                }

                if(event.getCharacter().equalsIgnoreCase("s")){
                    for(int i = 1; i < group.getChildren().size(); i++){
                        group.getChildren().get(i).setTranslateY(group.getChildren().get(i).getTranslateY()+10);
                    }
                }

                if(event.getCharacter().equalsIgnoreCase("d")){
                    for(int i = 1; i < group.getChildren().size(); i++){
                        group.getChildren().get(i).setTranslateX(group.getChildren().get(i).getTranslateX()+10);
                    }
                }

                if(event.getCharacter().equalsIgnoreCase("q")){
                    for(int i = 1; i < group.getChildren().size(); i++){
                        group.getChildren().get(i).setTranslateX(group.getChildren().get(i).getTranslateX()-10);
                    }
                }

            }
        });

        group.getChildren().addAll(menu,indicator);


        primaryStage.setTitle("LogiGraphics");
        primaryStage.setScene(scene);
        primaryStage.show();
        stage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }

    public void analyse(double posY,double posX){

        //créer une ligne entre la souris et le centre du cercle

        for(int i = 1; i < group.getChildren().size(); i++){
            if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Circle")){
                Circle circle = (Circle) group.getChildren().get(i);
                if(circle.getCenterX() > posX-3 && circle.getCenterX() < posX+3 || circle.getCenterY() > posY-3 && circle.getCenterY() < posY+3){
                  indicator.setOpacity(0.5);
                  indicator.setVisible(true);
                  indicator.setStartX(circle.getCenterX());
                  indicator.setStartY(circle.getCenterY());
                  indicator.setEndY(posY);
                  indicator.setEndX(posX);
                }else{
                    indicator.setVisible(false);
                }
            }
            if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Rectangle")){
                Rectangle circle = (Rectangle) group.getChildren().get(i);
                if(circle.getX() == posX || circle.getY() == posY){
                    indicator.setOpacity(0.5);
                    indicator.setVisible(true);
                    indicator.setStartX(circle.getX());
                    indicator.setStartY(circle.getY());
                    indicator.setEndY(posY);
                    indicator.setEndX(posX);
                }else {
                    indicator.setVisible(false);
                }
            }
            if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Line")){
                Line circle = (Line) group.getChildren().get(i);
                if(circle.getStartX() == posX || circle.getStartY() == posY){
                    indicator.setOpacity(0.5);
                    indicator.setVisible(true);
                    indicator.setStartX(circle.getStartX());
                    indicator.setStartY(circle.getStartY());
                    indicator.setEndY(posY);
                    indicator.setEndX(posX);
                }else if(circle.getEndX() == posX || circle.getEndY() == posY){
                    indicator.setOpacity(0.5);
                    indicator.setVisible(true);
                    indicator.setStartX(circle.getEndX());
                    indicator.setStartY(circle.getEndY());
                    indicator.setEndY(posY);
                    indicator.setEndX(posX);
                }
            }
        }


    }

    public void select(){
        for(int i = 1; i < group.getChildren().size(); i++){
            if(group.getChildren().get(i) == selected){

                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Circle")){
                    Circle c = (Circle) selected;
                    c.setFill(Color.RED);
                    c.setOpacity(0.5);
                }
                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Rectangle")){
                    Rectangle c = (Rectangle) selected;
                    c.setFill(Color.RED);
                    c.setOpacity(0.5);
                }
                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Line")){
                    Line c = (Line) selected;
                    c.setFill(Color.RED);
                    c.setOpacity(0.5);
                }

            }else{

                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Circle")){
                    Circle c = (Circle) group.getChildren().get(i);
                    c.setFill(Color.BLACK);
                    c.setOpacity(1);
                }
                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Rectangle")){
                    Rectangle c = (Rectangle) group.getChildren().get(i);
                    c.setFill(Color.BLACK);
                    c.setOpacity(1);
                }
                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Line")){
                    Line c = (Line) group.getChildren().get(i);
                    c.setFill(Color.BLACK);
                    c.setOpacity(1);
                }

            }

        }
    }

    public void menuSelector(){

        if(selector == 1){
            Button r = (Button) menu.getChildren().get(0);
            r.setTextFill(Color.RED);

            Button c = (Button) menu.getChildren().get(1);
            c.setTextFill(Color.BLACK);

            Button l = (Button) menu.getChildren().get(2);
            l.setTextFill(Color.BLACK);

        }
        if(selector == 2){
            Button r = (Button) menu.getChildren().get(0);
            r.setTextFill(Color.BLACK);

            Button c = (Button) menu.getChildren().get(1);
            c.setTextFill(Color.RED);

            Button l = (Button) menu.getChildren().get(2);
            l.setTextFill(Color.BLACK);
        }
        if(selector == 3){
            Button r = (Button) menu.getChildren().get(0);
            r.setTextFill(Color.BLACK);

            Button c = (Button) menu.getChildren().get(1);
            c.setTextFill(Color.BLACK);

            Button l = (Button) menu.getChildren().get(2);
            l.setTextFill(Color.RED);
        }
        if(selector == 4){
            Button r = (Button) menu.getChildren().get(0);
            r.setTextFill(Color.BLACK);

            Button c = (Button) menu.getChildren().get(1);
            c.setTextFill(Color.BLACK);

            Button l = (Button) menu.getChildren().get(2);
            l.setTextFill(Color.BLACK);
        }

    }

    public String randomTip(){
        Random r = new Random();
        int nb = r.nextInt(2);

        switch (nb){

            case 0:
                return "Vous pouvez changer de sélection en appuyant sur p !";

            case 1:
                return "Vous pouvez déplacer les éléments avec z q s et d !";


        }
        return "null";
    }

    public void back(){
        if(group.getChildren().size() > 2) {
            group.getChildren().remove(group.getChildren().size() - 1);
        }
    }

    public void save(){

    }
}
