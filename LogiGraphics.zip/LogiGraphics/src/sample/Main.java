package sample;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.util.Random;

public class Main extends Application {

    Stage primary;

    Group group = new Group();
    Scene scene = new Scene(group,1300,900, Color.GREY);

    boolean isOnAction = false;
    Node nodeAction = null;

    double moveX = 0;
    double moveY = 0;

    Node selected;

    int selector = 1;

    Circle circle;
    Rectangle rectangle;
    Line line;

    Line indicator = new Line();

   File workspace;

   MenuBar bar = new MenuBar();

    Menu formes = new Menu("Construire");
    Menu functions = new Menu("Fonctions");
    Menu files = new Menu("Fichiers");

    File superpose;

    /* selector :

    1 = rectangle
    2 = cercle
    3 = ligne
    4 = libre

     */

    @Override
    public void start(Stage primaryStage){

        addMenuItems();

        FileChooser chooser = new FileChooser();
        chooser.setTitle("Sélectionner un projet");
        workspace = chooser.showOpenDialog(primaryStage);

        Stage stage = new Stage();
        VBox box = new VBox();
        Label label = new Label();
        label.setText(randomTip());
        label.setFont(new Font("Trebuchet MS",15));
        box.getChildren().addAll(label);
        box.setAlignment(Pos.CENTER);
        stage.setScene(new Scene(box,500,225));
        stage.setTitle("Astuce du jour !");

        /*
        A DEV :

        -menu en dessous,on change de sélection avec u et on peut cliquer dessus en faisant entrée (sans besoin de cliquer dessus)
        -auto save
        -le menu a gauche apparait quand on sélectionne un truc,il permet de changer la couleur des éléments et leur taille
        -mettre github
        -bouton paramètres
        -gomme grace au substract (créer un rectangle qui efface)
        -outils fusion,qui combine les éléments (shape de ROMAINPC la vidép) (risque d'être assez dur)
        -mettre un icone en haut qui indique ce qu'on a choisi (rectangle,cercle,libre,gomme etc...)
         */

        //mettre les menus et fonctionnels

        scene.setOnMouseClicked(new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {

                if(!isOnAction){
                    if(selector != 4){
                        isOnAction = true;
                    }

                    if(selector == 1){

                        rectangle = new Rectangle();

                        rectangle.setOpacity(0.3);
                        rectangle.setY(event.getY());
                        rectangle.setX(event.getX());
                        rectangle.setWidth(6);
                        rectangle.setHeight(6);
                        nodeAction = rectangle;
                        rectangle.setOnMouseClicked(new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent event) {
                                if(selector == 4) {
                                    selected = rectangle;
                                    select();
                                }
                            }
                        });

                        group.getChildren().add(rectangle);
                    }

                    if(selector == 2){
                        circle = new Circle();

                        circle.setOpacity(0.3);
                        circle.setCenterX(event.getX());
                        circle.setCenterY(event.getY());
                        circle.setRadius(15);
                        nodeAction = circle;
                        circle.setOnMouseClicked(new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent event) {
                                if(selector == 4) {

                                    selected = circle;
                                    select();
                                }
                            }
                        });
                        group.getChildren().add(circle);
                    }

                    if(selector == 3){
                        line = new Line();

                        line.setOpacity(0.3);
                        line.setStartX(event.getX());
                        line.setStartY(event.getY());
                        line.setEndY(event.getX());
                        line.setEndY(event.getY());
                        nodeAction = line;
                        line.setOnMouseClicked(new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent event) {
                                if(selector == 4) {

                                    selected = line;
                                    select();
                                }
                            }
                        });
                        group.getChildren().add(line);
                    }


                }else{

                    if(nodeAction.getTypeSelector().equalsIgnoreCase("Circle")){
                        Circle c = (Circle) nodeAction;
                        c.setOpacity(1);
                        nodeAction = c;
                    }
                    if(nodeAction.getTypeSelector().equalsIgnoreCase("Rectangle")){
                        Rectangle c = (Rectangle) nodeAction;
                        c.setOpacity(1);
                        nodeAction = c;
                    }
                    if(nodeAction.getTypeSelector().equalsIgnoreCase("Line")){
                        Line c = (Line) nodeAction;
                        c.setOpacity(1);
                        nodeAction = c;
                    }

                   isOnAction = false;
                   nodeAction = null;
                   moveY = 0;
                   moveX = 0;
                   save();
                }

            }
        });

        scene.setOnMouseMoved(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                if(isOnAction){

                    if(selector == 1){

                        Rectangle circle1 = (Rectangle) nodeAction;
                        circle1.setWidth(event.getX()-circle1.getX());
                        circle1.setHeight(event.getY()-circle1.getY());
                        rectangle = circle1;

                    }

                    if(selector == 2){

                        moveY = event.getY();
                        moveX = event.getX();
                        Circle circle1 = (Circle) nodeAction;
                        circle1.setRadius(event.getX()-circle1.getCenterX());
                        circle = circle1;

                    }
                    if(selector == 3){
                        line.setEndX(event.getX());
                        line.setEndY(event.getY());
                    }

                }
                analyse(event.getY(), event.getX());
            }
        });

        scene.setOnKeyTyped(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {

                if(event.getCharacter().equalsIgnoreCase("p")){
                    selector++;
                    if(selector > 4){
                        selector = 1;
                    }
                }

                if(event.getCharacter().equalsIgnoreCase("z")){
                   moveY(true);
                }

                if(event.getCharacter().equalsIgnoreCase("s")){
                  moveY(false);
                }

                if(event.getCharacter().equalsIgnoreCase("d")){
                    moveX(true);
                }

                if(event.getCharacter().equalsIgnoreCase("q")){
                    moveX(false);
                }

            }
        });

        bar.getMenus().addAll(files,formes,functions);
        group.getChildren().addAll(bar,indicator);

        openProject();

        char[] na = workspace.getName().toCharArray();
        String name = "";
        for(int i = 0; i < na.length-4;i++){
            name += na[i];
        }

        primaryStage.setTitle("LogiGraphics - "+name);
        primaryStage.setScene(scene);
        primaryStage.show();
        primary = primaryStage;
        stage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }

    public void analyse(double posY,double posX){

        //créer une ligne entre la souris et le centre du cercle

        for(int i = 1; i < group.getChildren().size(); i++){
            if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Circle")){
                Circle circle = (Circle) group.getChildren().get(i);
                if(circle.getCenterX() > posX-3 && circle.getCenterX() < posX+3 || circle.getCenterY() > posY-3 && circle.getCenterY() < posY+3){
                  indicator.setOpacity(0.5);
                  indicator.setVisible(true);
                  indicator.setStartX(circle.getCenterX());
                  indicator.setStartY(circle.getCenterY());
                  indicator.setEndY(posY);
                  indicator.setEndX(posX);
                }else{
                    indicator.setVisible(false);
                }
            }
            if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Rectangle")){
                Rectangle circle = (Rectangle) group.getChildren().get(i);
                if(circle.getX() == posX || circle.getY() == posY){
                    indicator.setOpacity(0.5);
                    indicator.setVisible(true);
                    indicator.setStartX(circle.getX());
                    indicator.setStartY(circle.getY());
                    indicator.setEndY(posY);
                    indicator.setEndX(posX);
                }else {
                    indicator.setVisible(false);
                }
            }
            if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Line")){
                Line circle = (Line) group.getChildren().get(i);
                if(circle.getStartX() == posX || circle.getStartY() == posY){
                    indicator.setOpacity(0.5);
                    indicator.setVisible(true);
                    indicator.setStartX(circle.getStartX());
                    indicator.setStartY(circle.getStartY());
                    indicator.setEndY(posY);
                    indicator.setEndX(posX);
                }else if(circle.getEndX() == posX || circle.getEndY() == posY){
                    indicator.setOpacity(0.5);
                    indicator.setVisible(true);
                    indicator.setStartX(circle.getEndX());
                    indicator.setStartY(circle.getEndY());
                    indicator.setEndY(posY);
                    indicator.setEndX(posX);
                }
            }
        }


    }

    public void select(){
        for(int i = 1; i < group.getChildren().size(); i++){
            if(group.getChildren().get(i) == selected){

                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Circle")){
                    Circle c = (Circle) selected;
                    c.setFill(Color.RED);
                    c.setOpacity(0.5);
                }
                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Rectangle")){
                    Rectangle c = (Rectangle) selected;
                    c.setFill(Color.RED);
                    c.setOpacity(0.5);
                }
                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Line")){
                    Line c = (Line) selected;
                    c.setFill(Color.RED);
                    c.setOpacity(0.5);
                }

            }else{

                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Circle")){
                    Circle c = (Circle) group.getChildren().get(i);
                    c.setFill(Color.BLACK);
                    c.setOpacity(1);
                }
                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Rectangle")){
                    Rectangle c = (Rectangle) group.getChildren().get(i);
                    c.setFill(Color.BLACK);
                    c.setOpacity(1);
                }
                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Line")){
                    Line c = (Line) group.getChildren().get(i);
                    c.setFill(Color.BLACK);
                    c.setOpacity(1);
                }

            }

        }
    }

    public String randomTip(){
        Random r = new Random();
        int nb = r.nextInt(2);

        switch (nb){

            case 0:
                return "Vous pouvez changer de sélection en appuyant sur p !";

            case 1:
                return "Vous pouvez déplacer les éléments avec z q s et d !";


        }
        return "null";
    }

    public void moveY(boolean up){
        if(up) {
            for (int i = 2; i < group.getChildren().size(); i++) {
                if (group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Circle")) {
                    Circle circle = (Circle) group.getChildren().get(i);
                    circle.setCenterY(circle.getCenterY() - 10);
                    group.getChildren().set(i, circle);
                }
                if (group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Rectangle")) {
                    Rectangle r = (Rectangle) group.getChildren().get(i);
                    r.setY(r.getY() - 10);
                    group.getChildren().set(i, r);
                }

                if (group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Line")) {
                    Line line = (Line) group.getChildren().get(i);
                    line.setStartY(line.getStartY() - 10);
                    line.setEndY(line.getEndY() - 10);
                    group.getChildren().set(i, line);
                }

            }
        }else{
            for (int i = 2; i < group.getChildren().size(); i++) {
                if (group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Circle")) {
                    Circle circle = (Circle) group.getChildren().get(i);
                    circle.setCenterY(circle.getCenterY() + 10);
                    group.getChildren().set(i, circle);
                }
                if (group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Rectangle")) {
                    Rectangle r = (Rectangle) group.getChildren().get(i);
                    r.setY(r.getY() + 10);
                    group.getChildren().set(i, r);
                }

                if (group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Line")) {
                    Line line = (Line) group.getChildren().get(i);
                    line.setStartY(line.getStartY() + 10);
                    line.setEndY(line.getEndY() + 10);
                    group.getChildren().set(i, line);
                }

            }
        }
    }

    public void moveX(boolean right){
        if(!right) {
            for (int i = 2; i < group.getChildren().size(); i++) {
                if (group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Circle")) {
                    Circle circle = (Circle) group.getChildren().get(i);
                    circle.setCenterX(circle.getCenterX() - 10);
                    group.getChildren().set(i, circle);
                }
                if (group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Rectangle")) {
                    Rectangle r = (Rectangle) group.getChildren().get(i);
                    r.setX(r.getX() - 10);
                    group.getChildren().set(i, r);
                }

                if (group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Line")) {
                    Line line = (Line) group.getChildren().get(i);
                    line.setStartX(line.getStartX() - 10);
                    line.setEndX(line.getEndX() - 10);
                    group.getChildren().set(i, line);
                }

            }
        }else{
            for (int i = 2; i < group.getChildren().size(); i++) {
                if (group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Circle")) {
                    Circle circle = (Circle) group.getChildren().get(i);
                    circle.setCenterX(circle.getCenterX() + 10);
                    group.getChildren().set(i, circle);
                }
                if (group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Rectangle")) {
                    Rectangle r = (Rectangle) group.getChildren().get(i);
                    r.setX(r.getX() + 10);
                    group.getChildren().set(i, r);
                }

                if (group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Line")) {
                    Line line = (Line) group.getChildren().get(i);
                    line.setStartX(line.getStartX() + 10);
                    line.setEndX(line.getEndX() + 10);
                    group.getChildren().set(i, line);
                }

            }
        }
    }

    public void back(){
        if(group.getChildren().size() > 2) {
            group.getChildren().remove(group.getChildren().size() - 1);
        }
        save();
    }

    public void openProject(){

        try {

            FileReader fr = new FileReader(workspace);
            BufferedReader br = new BufferedReader(fr);

            String all = "";
            String str = "";
            while(str != null){
                str = br.readLine();
                if(str != null){
                    all += str;
                }
            }

            String[] values = all.split(":");
           for(int i = 0; i < values.length; i++){

               String[] properties = values[i].split("/");
               if(properties[0].equalsIgnoreCase("Rectangle")){

                   double posX = Double.parseDouble(properties[1]);
                   double posY = Double.parseDouble(properties[2]);
                   String[] pr = properties[3].split(",");

                   Rectangle r = new Rectangle();
                   r.setY(posY);
                   r.setX(posX);
                   r.setWidth(Double.parseDouble(pr[0]));
                   r.setHeight(Double.parseDouble(pr[1]));
                   group.getChildren().add(r);

               }
               if(properties[0].equalsIgnoreCase("Circle")){

                   double posX = Double.parseDouble(properties[1]);
                   double posY = Double.parseDouble(properties[2]);
                   double radius = Double.parseDouble(properties[3]);

                   Circle c = new Circle();
                   c.setCenterY(posY);
                   c.setCenterX(posX);
                   c.setRadius(radius);
                   group.getChildren().add(c);

               }
               if(properties[0].equalsIgnoreCase("Line")){

                   String[] start = properties[1].split(",");
                   String[] end = properties[2].split(",");

                   Line l = new Line();
                   l.setStartX(Double.parseDouble(start[0]));
                   l.setStartY(Double.parseDouble(start[1]));
                   l.setEndX(Double.parseDouble(end[0]));
                   l.setEndY(Double.parseDouble(end[1]));
                   group.getChildren().add(l);

               }

           }


        }catch (IOException e){
            System.out.println("error");
        }


    }

    /*
    C'est sous la forme :

    -Type
    -posX
    -PosY
    (pour les rectangles,width et height mais pour les cercles uniquement le Radius)
    -(le couleur quand elle sera mise)

     */

    public void save(){

        try {

            FileWriter fw = new FileWriter(workspace);
            BufferedWriter bw = new BufferedWriter(fw);

            for(int i = 3; i < group.getChildren().size();i++){

                bw.newLine();
                bw.write(":");
                bw.newLine();

                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Rectangle")){
                    Rectangle circle = (Rectangle) group.getChildren().get(i);
                    bw.write("Rectangle/");
                    bw.newLine();
                    bw.write(String.valueOf(circle.getX()+"/"));
                    bw.newLine();
                    bw.write(String.valueOf(circle.getY()+"/"));
                    bw.newLine();
                    bw.write(circle.getWidth() + "," + circle.getHeight());

                }
                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Line")){
                    Line circle = (Line) group.getChildren().get(i);
                    bw.write("Line/");
                    bw.newLine();
                    bw.write(circle.getStartX()+","+circle.getStartY()+"/");
                    bw.newLine();
                    bw.write(circle.getEndX()+","+circle.getEndY());

                }
                if(group.getChildren().get(i).getTypeSelector().equalsIgnoreCase("Circle")) {
                    Circle circle = (Circle) group.getChildren().get(i);
                    bw.write("Circle/");
                    bw.newLine();
                    bw.write(String.valueOf(circle.getCenterX()+"/"));
                    bw.newLine();
                    bw.write(String.valueOf(circle.getCenterY()+"/"));
                    bw.newLine();
                    bw.write(String.valueOf(circle.getRadius()));
                }
            }
            bw.write(":");
            bw.close();
            fw.close();

        }catch (IOException e){
            System.out.println("error");
        }

    }

    public void addMenuItems(){
        MenuItem rectangle = new MenuItem("🟫 Rectangle");
        rectangle.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                selector = 1;
            }
        });

        MenuItem circle = new MenuItem("⭕ Cercle");
        circle.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                selector = 2;
            }
        });

        MenuItem line = new MenuItem("〰 Ligne");
        line.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                selector = 3;
            }
        });

        MenuItem free = new MenuItem("🖱 Libre");
        free.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                selector = 4;
            }
        });

        formes.getItems().addAll(rectangle,circle,line,free);

        MenuItem draw = new MenuItem("✏ Dessin");


        MenuItem back = new MenuItem("↩ Retour");
        back.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                back();
            }
        });


        MenuItem eraser = new MenuItem("❌ Gomme");
        //fonction gomme

        MenuItem combiner = new MenuItem("🔗 Combiner");
        //fonction combiner les objets

        functions.getItems().addAll(draw,back,eraser,combiner);

        MenuItem create = new MenuItem("➕ Nouveau");
        create.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                int number = 1;
                File file = new File(System.getProperty("user.dir"),"projet"+number+".txt");
                while(file.exists()){
                    number++;
                    file = new File(System.getProperty("user.dir"),"projet"+number+".txt");
                }
                try {
                    file.createNewFile();

                    for(int i = 2; i < group.getChildren().size(); i++){
                        group.getChildren().removeAll(group.getChildren().get(i));
                    }
                    for(int i = 2; i < group.getChildren().size(); i++){
                        group.getChildren().removeAll(group.getChildren().get(i));
                    }
                    for(int i = 2; i < group.getChildren().size(); i++){
                        group.getChildren().removeAll(group.getChildren().get(i));
                    }
                    for(int i = 2; i < group.getChildren().size(); i++){
                        group.getChildren().removeAll(group.getChildren().get(i));
                    }
                    for(int i = 2; i < group.getChildren().size(); i++){
                        group.getChildren().removeAll(group.getChildren().get(i));
                    }
                    for(int i = 2; i < group.getChildren().size(); i++){
                        group.getChildren().removeAll(group.getChildren().get(i));
                    }
                    workspace = file;
                    char[] na = workspace.getName().toCharArray();
                    String name = "";
                    for(int i = 0; i < na.length-4;i++){
                        name += na[i];
                    }
                    primary.setTitle("LogiGraphics - "+name);
                    openProject();

                } catch (IOException e) {System.out.println("error");}


            }
        });

        MenuItem open = new MenuItem("📁 Ouvrir");
        open.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                for(int i = 2; i < group.getChildren().size(); i++){
                    group.getChildren().removeAll(group.getChildren().get(i));
                }
                for(int i = 2; i < group.getChildren().size(); i++){
                    group.getChildren().removeAll(group.getChildren().get(i));
                }
                for(int i = 2; i < group.getChildren().size(); i++){
                    group.getChildren().removeAll(group.getChildren().get(i));
                }
                for(int i = 2; i < group.getChildren().size(); i++){
                    group.getChildren().removeAll(group.getChildren().get(i));
                }
                for(int i = 2; i < group.getChildren().size(); i++){
                    group.getChildren().removeAll(group.getChildren().get(i));
                }
                for(int i = 2; i < group.getChildren().size(); i++){
                    group.getChildren().removeAll(group.getChildren().get(i));
                }
                FileChooser chooser = new FileChooser();
                chooser.setTitle("Sélectionner un projet");
                workspace = chooser.showOpenDialog(primary);
                char[] na = workspace.getName().toCharArray();
                String name = "";
                for(int i = 0; i < na.length-4;i++){
                    name += na[i];
                }
                primary.setTitle("LogiGraphics - "+name);
                openProject();
            }
        });

        MenuItem save = new MenuItem("✅ Enregistrer");
        save.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                save();
            }
        });

        MenuItem superposer = new MenuItem("📃 Superposer");
        superposer.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                FileChooser chooser = new FileChooser();
                chooser.setTitle("Sélectionner un projet");
                superpose = chooser.showOpenDialog(primary);
                openProject();
            }
        });

        files.getItems().addAll(create,open,save,superposer);
    }
}
